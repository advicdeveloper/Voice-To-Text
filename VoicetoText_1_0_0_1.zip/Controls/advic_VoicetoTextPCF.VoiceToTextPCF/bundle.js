/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./VoiceToTextPCF/index.ts":
/*!*********************************!*\
  !*** ./VoiceToTextPCF/index.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   VoiceToTextPCF: () => (/* binding */ VoiceToTextPCF)\n/* harmony export */ });\nclass VoiceToTextPCF {\n  constructor() {\n    this._recognition = null;\n  }\n  init(context, notifyOutputChanged, state, container) {\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._container = container;\n    this._finalText = context.parameters.controlValue.raw || \"\"; // Initialize with existing value\n    // Create textarea\n    this._textElement = document.createElement(\"textarea\");\n    this._textElement.setAttribute(\"rows\", \"5\");\n    this._textElement.value = this._finalText;\n    this._textElement.addEventListener(\"input\", this.onChange.bind(this));\n    container.appendChild(this._textElement);\n    // Create button\n    this._startButton = document.createElement(\"button\");\n    this._startButton.innerText = \"Start Speaking\";\n    this._startButton.addEventListener(\"click\", this.toggleRecognition.bind(this));\n    container.appendChild(this._startButton);\n    // Safe constructor selection\n    var SpeechRecognitionConstructor = window.SpeechRecognition || window.webkitSpeechRecognition;\n    if (SpeechRecognitionConstructor) {\n      this._recognition = new SpeechRecognitionConstructor();\n      this._recognition.continuous = true;\n      this._recognition.interimResults = true;\n      this._recognition.lang = \"en-US\";\n      this._recognition.onstart = () => {\n        this._startButton.innerText = \"Listening...\";\n      };\n      this._recognition.onresult = event => {\n        var interimTranscript = \"\";\n        var finalTranscript = \"\";\n        for (var i = event.resultIndex; i < event.results.length; ++i) {\n          var transcript = event.results[i][0].transcript;\n          if (event.results[i].isFinal) {\n            finalTranscript += transcript + \" \";\n          } else {\n            interimTranscript += transcript;\n          }\n        }\n        // Append final transcript to _finalText\n        if (finalTranscript) {\n          this._finalText += finalTranscript;\n        }\n        // Update textarea with final and interim results\n        this._textElement.value = this._finalText + interimTranscript;\n        this._value = this._finalText; // Only save final text to bound field\n        this._notifyOutputChanged();\n      };\n      this._recognition.onend = () => {\n        this._startButton.innerText = \"Start Speaking\";\n        // Ensure textarea shows only final text when recognition ends\n        this._textElement.value = this._finalText;\n        this._value = this._finalText;\n        this._notifyOutputChanged();\n      };\n      this._recognition.onerror = event => {\n        console.error(\"Speech recognition error:\", event.error, event.message);\n        this._startButton.innerText = \"Start Speaking\";\n        this._startButton.disabled = event.error === \"no-speech\" || event.error === \"aborted\" ? false : true;\n        this._textElement.value = this._finalText + \"\\n[Error: \".concat(event.error, \"]\");\n        this._value = this._finalText; // Keep _value as final text\n        this._notifyOutputChanged();\n      };\n    } else {\n      this._startButton.disabled = true;\n      this._startButton.innerText = \"Browser Not Supported\";\n    }\n  }\n  updateView(context) {\n    var newValue = context.parameters.controlValue.raw || \"\";\n    if (this._finalText !== newValue) {\n      this._finalText = newValue;\n      this._textElement.value = newValue;\n      this._value = newValue;\n    }\n  }\n  getOutputs() {\n    return {\n      controlValue: this._value || \"\"\n    };\n  }\n  destroy() {\n    if (this._recognition) {\n      this._recognition.stop();\n      this._recognition.onresult = null;\n      this._recognition.onend = null;\n      this._recognition.onerror = null;\n    }\n    this._startButton.removeEventListener(\"click\", this.toggleRecognition.bind(this));\n    this._textElement.removeEventListener(\"input\", this.onChange.bind(this));\n  }\n  onChange() {\n    this._finalText = this._textElement.value;\n    this._value = this._finalText;\n    this._notifyOutputChanged();\n  }\n  toggleRecognition() {\n    if (!this._recognition) return;\n    if (this._startButton.innerText === \"Start Speaking\") {\n      this._recognition.start();\n      this._startButton.innerText = \"Listening...\";\n    } else {\n      this._recognition.stop();\n      this._startButton.innerText = \"Start Speaking\";\n    }\n  }\n}\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./VoiceToTextPCF/index.ts?\n}");

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The require scope
/******/ 	var __webpack_require__ = {};
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module can't be inlined because the eval devtool is used.
/******/ 	var __webpack_exports__ = {};
/******/ 	__webpack_modules__["./VoiceToTextPCF/index.ts"](0, __webpack_exports__, __webpack_require__);
/******/ 	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = __webpack_exports__;
/******/ 	
/******/ })()
;
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('VoicetoTextPCF.VoiceToTextPCF', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.VoiceToTextPCF);
} else {
	var VoicetoTextPCF = VoicetoTextPCF || {};
	VoicetoTextPCF.VoiceToTextPCF = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.VoiceToTextPCF;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}