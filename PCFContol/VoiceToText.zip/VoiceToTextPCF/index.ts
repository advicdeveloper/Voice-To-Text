import { IInputs, IOutputs } from "./generated/ManifestTypes";

// -------------------
// Speech Recognition Types (inline, ESLint-safe)
// -------------------

interface SpeechRecognition extends EventTarget {
    continuous: boolean;
    interimResults: boolean;
    lang: string;
    start(): void;
    stop(): void;
    abort(): void;

    onaudioend: ((this: SpeechRecognition, ev: Event) => void) | null;
    onaudiostart: ((this: SpeechRecognition, ev: Event) => void) | null;
    onend: ((this: SpeechRecognition, ev: Event) => void) | null;
    onerror: ((this: SpeechRecognition, ev: SpeechRecognitionErrorEvent) => void) | null;
    onresult: ((this: SpeechRecognition, ev: SpeechRecognitionEvent) => void) | null;
}

type SpeechRecognitionConstructor = new () => SpeechRecognition;

declare const SpeechRecognition: SpeechRecognitionConstructor;
declare const webkitSpeechRecognition: SpeechRecognitionConstructor;

interface SpeechRecognitionEvent extends Event {
    resultIndex: number;
    results: SpeechRecognitionResultList;
}

interface SpeechRecognitionErrorEvent extends Event {
    error: string;
    message: string;
}

// -------------------
// PCF Control
// -------------------

export class VoiceToTextPCF implements ComponentFramework.StandardControl<IInputs, IOutputs> {
    private _context: ComponentFramework.Context<IInputs>;
    private _notifyOutputChanged: () => void;
    private _container: HTMLDivElement;
    private _textElement: HTMLTextAreaElement;
    private _startButton: HTMLButtonElement;
    private _recognition: SpeechRecognition | null = null;
    private _value: string | undefined;

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: Record<string, unknown>, // ✅ no `any`
        container: HTMLDivElement
    ): void {
        this._context = context;
        this._notifyOutputChanged = notifyOutputChanged;
        this._container = container;

        // Create textarea
        this._textElement = document.createElement("textarea");
        this._textElement.setAttribute("rows", "5");
        this._textElement.value = context.parameters.controlValue.raw || "";
        this._textElement.addEventListener("input", this.onChange.bind(this));
        container.appendChild(this._textElement);

        // Create button
        this._startButton = document.createElement("button");
        this._startButton.innerText = "Start Speaking";
        this._startButton.addEventListener("click", this.toggleRecognition.bind(this));
        container.appendChild(this._startButton);

        // Safe constructor selection
        const SpeechRecognitionConstructor: SpeechRecognitionConstructor | undefined =
            (window as Partial<{ SpeechRecognition: SpeechRecognitionConstructor }>).SpeechRecognition
            || (window as Partial<{ webkitSpeechRecognition: SpeechRecognitionConstructor }>).webkitSpeechRecognition;

        if (SpeechRecognitionConstructor) {
            this._recognition = new SpeechRecognitionConstructor();
            this._recognition.continuous = true;
            this._recognition.interimResults = true;
            this._recognition.lang = "en-US";

            this._recognition.onresult = (event: SpeechRecognitionEvent) => {
                let transcript = "";
                for (let i = event.resultIndex; i < event.results.length; ++i) {
                    transcript += event.results[i][0].transcript;
                }
                this._textElement.value += transcript;
                this._value = this._textElement.value;
                this._notifyOutputChanged();
            };

            this._recognition.onend = () => {
                this._startButton.innerText = "Start Speaking";
            };

            this._recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
                console.error("Speech recognition error:", event.error);
                this._startButton.innerText = "Start Speaking";
            };
        } else {
            this._startButton.disabled = true;
            this._startButton.innerText = "Browser Not Supported";
        }
    }

    public updateView(context: ComponentFramework.Context<IInputs>): void {
        this._textElement.value = context.parameters.controlValue.raw || "";
    }

    public getOutputs(): IOutputs {
        return {
            controlValue: this._value
        };
    }

    public destroy(): void {
        if (this._recognition) {
            this._recognition.stop();
        }
    }

    private onChange(): void {
        this._value = this._textElement.value;
        this._notifyOutputChanged();
    }

    private toggleRecognition(): void {
        if (!this._recognition) return;

        if (this._startButton.innerText === "Start Speaking") {
            this._recognition.start();
            this._startButton.innerText = "Stop Speaking";
        } else {
            this._recognition.stop();
            this._startButton.innerText = "Start Speaking";
        }
    }
}
